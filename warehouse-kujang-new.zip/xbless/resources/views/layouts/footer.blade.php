<div class="footer">
    <div class="pull-right">
        CV KUJANG MARINAS UTAMA
    </div>
    <div>
        <strong>Copyright</strong> Buruh Ketik &copy; 2022
    </div>
</div>
