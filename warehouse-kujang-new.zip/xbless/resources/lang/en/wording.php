<?php

return [
  'menu_home'    => 'Beranda',
];
