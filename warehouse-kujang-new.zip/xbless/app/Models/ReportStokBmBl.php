<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ReportStokBmBl extends Model
{
    use HasFactory;

    protected $table = 'report_stok_bm_bl';
    protected $guarded = [];
}
