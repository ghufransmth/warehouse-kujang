<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeChannel extends Model
{
    use HasFactory;
    protected $table    = 'type_channel';
    public $timestamps = false;
}
