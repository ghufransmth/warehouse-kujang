<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductPerusahaanGudang extends Model
{
    use HasFactory;
    protected $table    = 'product_perusahaan_gudang';
    public $timestamps = false;
    protected $guarded = [];
}
